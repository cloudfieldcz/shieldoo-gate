def hello(): return "hi from acme-widget"

def hello(): return "hi from mycompany-lib"

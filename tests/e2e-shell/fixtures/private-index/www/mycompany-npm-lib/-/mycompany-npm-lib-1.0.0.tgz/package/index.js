module.exports = function () { return "hi from mycompany-npm-lib"; };

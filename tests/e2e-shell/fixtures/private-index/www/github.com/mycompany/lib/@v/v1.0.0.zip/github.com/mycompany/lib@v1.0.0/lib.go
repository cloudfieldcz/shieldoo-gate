package lib

// Hello is an E2E private-module fixture.
func Hello() string { return "hi from github.com/mycompany/lib" }
